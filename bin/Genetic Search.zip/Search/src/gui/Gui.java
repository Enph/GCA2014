package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import mapgeneration.Labrynth;
import mapgeneration.Maze;

import agency.Agent;
import agency.AgentThread;
import agency.Position;

public class Gui extends JFrame{
	private static final long serialVersionUID = 8284475243304944040L;
	public static boolean finished = false;
	private static Gui gui;
	private MazePanel mazePanel;
	private static Maze maze;
	public Gui(){//(-3 3) (-2 3) (-1 3) (-1 2) (-1 1) (0 1) (0 0)
		super("A* search");
		setSize(600,700);
		setLayout(new BorderLayout());
		this.addWindowListener(new WindowAdapter(){
			@Override
			public void windowClosing(WindowEvent e){
				finished = true;
				System.exit(1);
			}
		});
		mazePanel = new MazePanel();
		add(mazePanel,BorderLayout.CENTER);
		setVisible(true);
		repaint();
	}
	public static synchronized void draw(Maze maze){
		if(gui!=null){
			Gui.maze = maze;
			gui.repaint();
		}
	}
	public static void start() {
		gui = new Gui();
		Labrynth lab = new Labrynth(12);
		lab.start();
	}
	public class MazePanel extends JPanel{
		private static final long serialVersionUID = 3348271560731604756L;
		private int blockwidth;
		private int blockheight;
		public MazePanel(){
			super();
			this.setPreferredSize(new Dimension(600,700));
			this.setBackground(Color.white);
		}
		@Override
		public void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setColor(Color.black);
			blockwidth = this.getWidth()/maze.getWidth();
			blockheight = (this.getHeight()-50)/(maze.getHeight());
			for(ArrayList<Position> positions:maze){
				for(Position position:positions){
					if(position.isObstacle()){
						g.fillRect((position.x)*blockwidth, this.getHeight()-(position.y+1)*blockheight, blockwidth, blockheight);
					}
					else {
						g.drawRect((position.x)*blockwidth, this.getHeight()-(position.y+1)*blockheight, blockwidth, blockheight);
					}
				}
			}
			g.drawString(Labrynth.generation.toString(),400,10);
			g.drawString(maze.getFitness().toString(),500,10);
			g.setColor(new Color(200,10,200));
			try{
			  for(Agent agent:maze.getAgents()){
				agent.draw(g,blockwidth,blockheight,getHeight());
			  }
			}
			catch(java.util.ConcurrentModificationException e){
				
			}
			catch(java.util.NoSuchElementException e){
				
			}
			catch(java.lang.NullPointerException e){
				
			}
			g.setColor(Color.blue);
			g.fillRect((maze.getGoal().x)*blockwidth, this.getHeight()-(maze.getGoal().y+1)*blockheight, blockwidth, blockheight);
			
		}
	}
	
	
}
