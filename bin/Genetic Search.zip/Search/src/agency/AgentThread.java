package agency;

import gui.Gui;

public class AgentThread extends Thread{
	private Agent smith;
	public AgentThread(Agent agent){
		super();
		smith = agent;
	}
	@Override
	public void run(){
		while(!smith.isFinished()&&!smith.hasFailed()&&!Gui.finished){
			smith.step();
			if(!smith.hasFailed()){
				//Gui.draw();
			}
		}
		smith.report();
	}
}