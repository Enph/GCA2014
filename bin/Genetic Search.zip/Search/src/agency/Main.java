package agency;
import gui.Gui;

import java.util.TreeSet;

import mapgeneration.Labrynth;


public class Main {
	public Main(){
		Labrynth lab = new Labrynth(10);
	}
	public static void main(String[] args){
		Gui.start();
	}
	
}
