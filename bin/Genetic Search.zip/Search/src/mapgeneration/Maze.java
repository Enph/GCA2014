package mapgeneration;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import agency.Agent;
import agency.Move;
import agency.Path;
import agency.Position;


public class Maze extends ArrayList<ArrayList<Position>> implements Comparable<Maze>{
	private static final long serialVersionUID = -4974919269738609258L;
	private Position goal;
	private static int width=30;
	private static int height=30;
	private static float mutationRate = 0.005f;
	private static float goalMutationRate = 0.000f;
	private int length = 0;
	private List<Agent> agents;

	public Maze(boolean generate) {
		super(width);
		agents = new ArrayList<Agent>();
		for(int x=0;x<width;x++){
			add(new ArrayList<Position>(height));
			for(int y=0;y<height;y++){
				get(x).add(new Position(x,y));
			}
		}
		if(generate){
			for(int i=0;i<width;++i){
				for(int j=0;j<height;++j){
					if(Math.random()<0.25f){
						get(i,j).obstacle();
					}
				}
			}
		}
		goal = get(width-1,height-1);
		if(goal.isObstacle()){
			goal.toggleObstacle();
		}

	}
	public int getCost(Path path) {
		int cost = 0;
		int x = path.getLast().x;
		int y = path.getLast().y;
		while(y<goal.y){
			++y;
			++cost;
			if(get(x,y).isObstacle()){
				++cost;
			}
		}
		while(y>goal.y){
			--y;
			++cost;
			if(get(x,y).isObstacle()){
				++cost;
			}
		}
		while(x<goal.x){
			++x;
			++cost;
			if(get(x,y).isObstacle()){
				++cost;
			}
		}
		while(x>goal.x){
			--x;
			++cost;
			if(get(x,y).isObstacle()){
				++cost;
			}
		}
		return cost;
	}
	public int getWidth() {
		return width;
	}
	public Position get(int x, int y) {
		return get(x).get(y);
	}
	public int getHeight() {
		return height;
	}
	public Position getGoal() {
		return goal;
	}
	public void report(int size, Agent agent) {
		length=size;
		agents.add(agent);
	}
	public List<Agent> getAgents(){
		return agents;
	}
	public void mutate(){
		for(int i=0;i<width;++i){
			for(int j=0;j<height;++j){
				if(Math.random()<mutationRate){
					get(i,j).toggleObstacle();
				}
			}
		}
		if(Math.random()<goalMutationRate){
			goal = get(goal.x+1,goal.y);
			if(goal.isObstacle()){
				goal.toggleObstacle();
			}
		}
		else if(Math.random()<goalMutationRate){
			goal = get(goal.x,goal.y+1);
			if(goal.isObstacle()){
				goal.toggleObstacle();
			}
		}
		else if(Math.random()<goalMutationRate){
			goal = get(goal.x,goal.y-1);
			if(goal.isObstacle()){
				goal.toggleObstacle();
			}
		}
		else if(Math.random()<goalMutationRate){
			goal = get(goal.x-1,goal.y);
			if(goal.isObstacle()){
				goal.toggleObstacle();
			}
		}
		
	}
	public Maze crossover(Maze other){
		Maze maze = new Maze(false);
		int m=(int) (Math.random()*width);
		int n=(int) (Math.random()*height);
		for(int i=0;i<m;++i){
			for(int j=0;j<n;++j){
				if(this.get(i,j).isObstacle()){
					maze.get(i,j).obstacle();
				}
			}
		}
		for(int i=m;i<width;++i){
			for(int j=n;j<height;++j){
				if(this.get(i,j).isObstacle()){
					maze.get(i,j).obstacle();
				}
			}
		}
		for(int i=m;i<width;++i){
			for(int j=0;j<n;++j){
				if(other.get(i,j).isObstacle()){
					maze.get(i,j).obstacle();
				}
			}
		}
		for(int i=0;i<m;++i){
			for(int j=n;j<height;++j){
				if(other.get(i,j).isObstacle()){
					maze.get(i,j).obstacle();
				}
			}
		}
		maze.goal = maze.get(goal.x,goal.y);
		if(maze.goal.isObstacle()){
			maze.goal.toggleObstacle();
		}
		return maze;
	}
	public Integer getFitness() {
		return length;
	}
	@Override
	public int compareTo(Maze maze) {
		int cost = maze.length-length;
		return cost==0?-1:cost;
	}


}
