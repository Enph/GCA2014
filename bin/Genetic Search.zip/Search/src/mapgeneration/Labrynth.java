package mapgeneration;

import gui.Gui;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import agency.Agent;
import agency.AgentThread;
import agency.Path;

public class Labrynth extends ArrayList<Maze>{
	private static final long serialVersionUID = -7227849721784005391L;
	public static Maze maze;
	public static List<Agent> agents;
	public static List<AgentThread> agentThreads;
	public static Integer generation;

	public Labrynth(int i) {
		super(i);
		for(int j=0;j<i;++j){
			add(new Maze(true));
		}
		agents = new ArrayList<Agent>();
		agentThreads = new ArrayList<AgentThread>();
	}

	public void test(Maze maze)
	{
		agents.clear();
		agentThreads.clear();
		Labrynth.maze = maze;			
		agents.add(new Agent("#1",0,0,maze));
		//agents.add(new Agent("#2",0,maze.getHeight()-1,maze));
		//agents.add(new Agent("#3",maze.getWidth()-1,maze.getHeight()-1,maze));
		//agents.add(new Agent("#4",maze.getWidth()-1,0,maze));
		for(Agent agent:agents){
			agentThreads.add(new AgentThread(agent));
		}
		for(AgentThread agent:agentThreads){
			agent.start();
		}
		for(AgentThread agent:agentThreads){
			try {
				agent.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(maze.getFitness());
		//Gui.draw(maze);
	}

	/*
	 * Goes through as many generations as are in the for loop
	 */	
	public void start() {
		Maze last = null;
		for(generation=0;generation<100;++generation)
		{
			TreeSet<Maze> mazes = new TreeSet<Maze>();
			for(Maze maze:this){
				test(maze);
				mazes.add(maze);
			}
			List<Maze> newMazes = new ArrayList<Maze>();
			Maze[] set = mazes.toArray(new Maze[0]);
			last = set[0];
			Gui.draw(last);
			for(int j=0;j<set.length;++j)
			{
				for(int k=0;k<5&&newMazes.size()<size();++k)
				{
					maze = set[j].crossover(set[k]);
					maze.mutate();
					newMazes.add(maze);
				}
			}
			clear();
			addAll(newMazes);
		}
		test(last);
		System.out.println(last.getFitness());
		Gui.draw(last);
	}

}

